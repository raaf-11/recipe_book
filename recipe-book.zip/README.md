# Recipe Book - Google Stitch Home Page

This project is a pixel-perfect, production-ready React implementation of the exported Google Stitch Home Page design for **Recipe Book**.

## Features

- **Pixel-Perfect Design**: Recreates the exported Google Stitch design including layout, color tokens, typography, spacing, and hover animations.
- **Modular Component Architecture**: Divided into reusable functional components (`Navbar`, `Hero`, `SearchBar`, `CategoryFilter`, `RecipeCard`, `Button`, `Footer`).
- **Interactive State**:
  - Live search filtering by recipe name, ingredients, or category.
  - Interactive category selection chips.
  - Interactive recipe bookmarking with badge counters.
  - Recipe quick-view modal.
  - AI Sous Chef assistant modal.
- **Tailwind CSS Integration**: Styled using Tailwind CSS v4 with custom warm gradient utilities and design system theme tokens.

---

## Project Structure

```
src/
├── components/
│   ├── Button.jsx          # Reusable button component
│   ├── CategoryFilter.jsx  # Category filter pills bar
│   ├── Footer.jsx          # Application footer
│   ├── Hero.jsx            # Hero section header
│   ├── Navbar.jsx          # Sticky top navigation bar
│   ├── RecipeCard.jsx      # Recipe card component with image hover zoom
│   └── SearchBar.jsx       # Search input component
├── layouts/
│   └── MainLayout.jsx      # Main layout wrapper
├── pages/
│   └── Home.jsx            # Home page component uniting all modules
├── utils/
│   └── recipes.js          # Mock dataset & category constants
├── App.tsx                 # Root application component
├── index.css               # Global CSS & Tailwind configuration
└── main.tsx                # React entry point
```

---

## Getting Started

### Prerequisites

Ensure you have Node.js (version 18 or above) installed.

### Installation

1. Install project dependencies:
```bash
npm install
```

2. Run the development server:
```bash
npm run dev
```

3. Open your browser and navigate to `http://localhost:3000`.

---

## Production Build

To build the application for production:

```bash
npm run build
```

To preview the production build locally:

```bash
npm run preview
```

---

## Customization

- **Recipes Data**: Add or modify recipes in `src/utils/recipes.js`.
- **Colors & Theme**: Adjust color tokens in `src/index.css` under the `@theme` block.
