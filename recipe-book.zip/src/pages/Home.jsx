import React, { useState, useMemo } from 'react';
import Hero from '../components/Hero';
import CategoryFilter from '../components/CategoryFilter';
import RecipeCard from '../components/RecipeCard';
import MainLayout from '../layouts/MainLayout';
import { INITIAL_RECIPES } from '../utils/recipes';
import { Search, X, Sparkles, ChefHat, Bookmark, Check } from 'lucide-react';

// Main Home Page Component converting Google Stitch Home Page Export
export default function Home() {
  const [recipes, setRecipes] = useState(INITIAL_RECIPES);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchValue, setSearchValue] = useState('');
  const [showBookmarksOnly, setShowBookmarksOnly] = useState(false);
  const [selectedRecipeModal, setSelectedRecipeModal] = useState(null);
  const [showAiModal, setShowAiModal] = useState(false);
  const [aiQuery, setAiQuery] = useState('');
  const [aiSuggestions, setAiSuggestions] = useState(null);

  // Toggle bookmark state for a recipe
  const handleToggleBookmark = (id) => {
    setRecipes((prev) =>
      prev.map((r) => (r.id === id ? { ...r, isBookmarked: !r.isBookmarked } : r))
    );
  };

  // Total bookmarked recipes count
  const bookmarkCount = useMemo(() => {
    return recipes.filter((r) => r.isBookmarked).length;
  }, [recipes]);

  // Filtered recipe list based on category, search query, and bookmark filter
  const filteredRecipes = useMemo(() => {
    return recipes.filter((recipe) => {
      // Bookmark filter check
      if (showBookmarksOnly && !recipe.isBookmarked) return false;

      // Category filter check
      const matchesCategory =
        selectedCategory === 'All' ||
        recipe.category === selectedCategory ||
        recipe.cuisine === selectedCategory;

      // Search query check
      const query = searchValue.toLowerCase().trim();
      const matchesSearch =
        !query ||
        recipe.title.toLowerCase().includes(query) ||
        recipe.description.toLowerCase().includes(query) ||
        recipe.cuisine.toLowerCase().includes(query) ||
        recipe.category.toLowerCase().includes(query);

      return matchesCategory && matchesSearch;
    });
  }, [recipes, selectedCategory, searchValue, showBookmarksOnly]);

  // Handle AI Assistant recommendation query
  const handleAiSearch = (e) => {
    e.preventDefault();
    if (!aiQuery.trim()) return;

    // Simulate AI cooking assistant response based on prompt
    const suggestions = [
      'Creamy Mushroom Risotto - perfect comfort dish',
      'Spicy Avocado Toast - fast & energizing',
      'Mediterranean Quinoa Bowl - fresh & healthy',
    ];
    setAiSuggestions(suggestions);
  };

  return (
    <MainLayout
      bookmarkCount={bookmarkCount}
      onBookmarkClick={() => setShowBookmarksOnly((prev) => !prev)}
      onAiAssistantClick={() => setShowAiModal(true)}
    >
      {/* Hero Section */}
      <Hero
        searchValue={searchValue}
        setSearchValue={setSearchValue}
        onSearchSubmit={() => {}}
      />

      {/* Main Content Canvas */}
      <section className="max-w-[1200px] mx-auto px-4 md:px-10 py-12 md:py-16">
        {/* Active Filter Banner if viewing saved bookmarks */}
        {showBookmarksOnly && (
          <div className="mb-6 p-4 bg-primary/10 border border-primary/20 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-2 text-primary font-medium">
              <Bookmark className="w-5 h-5 fill-current" />
              <span>Showing {bookmarkCount} Saved Bookmarks</span>
            </div>
            <button
              onClick={() => setShowBookmarksOnly(false)}
              className="text-xs font-semibold text-primary underline hover:opacity-80"
            >
              Show All Recipes
            </button>
          </div>
        )}

        {/* Category Filter Pills */}
        <CategoryFilter
          selectedCategory={selectedCategory}
          onSelectCategory={(cat) => {
            setSelectedCategory(cat);
            setShowBookmarksOnly(false);
          }}
        />

        {/* Recipe Cards Grid */}
        {filteredRecipes.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRecipes.map((recipe) => (
              <RecipeCard
                key={recipe.id}
                recipe={recipe}
                onToggleBookmark={handleToggleBookmark}
                onClickCard={(r) => setSelectedRecipeModal(r)}
              />
            ))}
          </div>
        ) : (
          /* Empty State */
          <div className="text-center py-16 bg-white rounded-2xl border border-slate-100 p-8">
            <Search className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-on-surface">No recipes found</h3>
            <p className="text-sm text-secondary mt-1">
              Try adjusting your search query or category filters.
            </p>
            <button
              onClick={() => {
                setSearchValue('');
                setSelectedCategory('All');
                setShowBookmarksOnly(false);
              }}
              className="mt-4 px-6 py-2 bg-primary text-white text-sm font-semibold rounded-full btn-hover"
            >
              Reset Filters
            </button>
          </div>
        )}
      </section>

      {/* Recipe Quick View Modal */}
      {selectedRecipeModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-100 animate-fade-in-up">
            <div className="relative h-60 bg-slate-100">
              <img
                src={selectedRecipeModal.image}
                alt={selectedRecipeModal.title}
                className="w-full h-full object-cover"
              />
              <button
                onClick={() => setSelectedRecipeModal(null)}
                className="absolute top-4 right-4 p-2 bg-black/50 text-white rounded-full hover:bg-black/70 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6">
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2.5 py-0.5 rounded bg-tertiary-fixed text-on-tertiary-fixed text-xs font-bold uppercase">
                  {selectedRecipeModal.cuisine}
                </span>
                <span className="text-xs text-secondary font-medium ml-auto">
                  ⏱ {selectedRecipeModal.time}
                </span>
              </div>
              <h2 className="text-2xl font-bold text-on-surface mb-2">
                {selectedRecipeModal.title}
              </h2>
              <p className="text-secondary text-sm mb-6 leading-relaxed">
                {selectedRecipeModal.description}
              </p>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    handleToggleBookmark(selectedRecipeModal.id);
                    setSelectedRecipeModal((prev) =>
                      prev ? { ...prev, isBookmarked: !prev.isBookmarked } : null
                    );
                  }}
                  className={`flex-1 py-3 rounded-full font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
                    selectedRecipeModal.isBookmarked
                      ? 'bg-primary/10 text-primary border border-primary/20'
                      : 'bg-primary text-white hover:bg-primary-container hover:text-on-primary-container'
                  }`}
                >
                  <Bookmark className={`w-4 h-4 ${selectedRecipeModal.isBookmarked ? 'fill-current' : ''}`} />
                  {selectedRecipeModal.isBookmarked ? 'Bookmarked' : 'Save Recipe'}
                </button>
                <button
                  onClick={() => setSelectedRecipeModal(null)}
                  className="px-6 py-3 rounded-full bg-slate-100 text-secondary hover:bg-slate-200 text-sm font-semibold"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* AI Assistant Modal */}
      {showAiModal && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 animate-fade-in-up">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 text-primary font-bold text-lg">
                <Sparkles className="w-5 h-5 text-primary" />
                <span>AI Sous Chef</span>
              </div>
              <button
                onClick={() => {
                  setShowAiModal(false);
                  setAiSuggestions(null);
                  setAiQuery('');
                }}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-sm text-secondary mb-4">
              Ask what to cook with leftover ingredients or request personalized meal recommendations!
            </p>
            <form onSubmit={handleAiSearch} className="space-y-3">
              <input
                type="text"
                value={aiQuery}
                onChange={(e) => setAiQuery(e.target.value)}
                placeholder="e.g., I have mushrooms, eggs, and bread..."
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-primary focus:border-primary text-sm outline-none"
              />
              <button
                type="submit"
                className="w-full py-3 bg-primary text-white font-semibold text-sm rounded-xl hover:bg-primary-container hover:text-on-primary-container transition-colors flex items-center justify-center gap-2"
              >
                <ChefHat className="w-4 h-4" />
                Generate Recipe Ideas
              </button>
            </form>

            {aiSuggestions && (
              <div className="mt-4 pt-4 border-t border-slate-100 space-y-2">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Recommended Recipes:
                </p>
                {aiSuggestions.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-warm-gradient rounded-xl text-xs font-medium text-slate-700 flex items-center gap-2"
                  >
                    <Check className="w-4 h-4 text-primary shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </MainLayout>
  );
}
