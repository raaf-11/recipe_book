import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

// Main layout wrapper including sticky header, main content area, and footer
export default function MainLayout({
  children,
  bookmarkCount = 0,
  onBookmarkClick,
  onAiAssistantClick,
}) {
  return (
    <div className="bg-background text-on-background min-h-screen flex flex-col font-sans selection:bg-primary/20 selection:text-primary">
      {/* Top Header Navigation */}
      <Navbar
        bookmarkCount={bookmarkCount}
        onBookmarkClick={onBookmarkClick}
        onAiAssistantClick={onAiAssistantClick}
      />

      {/* Main Page Content */}
      <main className="flex-grow">{children}</main>

      {/* Application Footer */}
      <Footer />
    </div>
  );
}
