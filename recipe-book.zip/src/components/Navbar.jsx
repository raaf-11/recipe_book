import React from 'react';
import { UtensilsCrossed, Bookmark, Bot, User, LogOut } from 'lucide-react';

// Main navigation bar component matching Google Stitch layout
export default function Navbar({
  bookmarkCount = 0,
  onBookmarkClick,
  onAiAssistantClick,
}) {
  return (
    <header className="bg-surface h-[72px] w-full sticky top-0 z-50 shadow-[0_4px_20px_rgba(0,0,0,0.04)] transition-all duration-200 border-b border-slate-100">
      <div className="flex justify-between items-center px-6 md:px-10 max-w-[1200px] mx-auto h-full w-full">
        {/* Brand Logo */}
        <a
          href="#"
          className="flex items-center gap-2 font-headline-md text-2xl font-bold text-on-surface hover:opacity-80 transition-opacity duration-200"
        >
          <UtensilsCrossed className="w-8 h-8 text-primary" />
          <span>Recipe Book</span>
        </a>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Bookmark list toggle */}
          <button
            onClick={onBookmarkClick}
            aria-label="Bookmarks"
            className="relative p-2 rounded-full text-secondary hover:text-primary hover:bg-surface-container-highest transition-all duration-200 active:scale-95"
            title="Saved Bookmarks"
          >
            <Bookmark className="w-6 h-6" />
            {bookmarkCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-primary text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-white">
                {bookmarkCount}
              </span>
            )}
          </button>

          {/* AI Assistant Button */}
          <button
            onClick={onAiAssistantClick}
            aria-label="AI Cooking Assistant"
            className="p-2 rounded-full text-secondary hover:text-primary hover:bg-surface-container-highest transition-all duration-200 active:scale-95"
            title="AI Chef Assistant"
          >
            <Bot className="w-6 h-6" />
          </button>

          {/* User Profile Pill */}
          <div className="flex items-center gap-1.5 p-1 pr-3 rounded-full hover:bg-surface-container-highest transition-all duration-200 cursor-pointer active:scale-95">
            <div className="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center text-secondary">
              <User className="w-4 h-4" />
            </div>
            <span className="font-label-md text-sm font-medium text-secondary">Alex</span>
          </div>

          {/* Logout Button */}
          <button
            aria-label="Logout"
            className="p-2 rounded-full text-secondary hover:text-primary hover:bg-surface-container-highest transition-all duration-200 active:scale-95"
            title="Sign Out"
          >
            <LogOut className="w-6 h-6" />
          </button>
        </div>
      </div>
    </header>
  );
}
