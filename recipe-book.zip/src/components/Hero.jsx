import React from 'react';
import SearchBar from './SearchBar';

// Hero header section component
export default function Hero({ searchValue, setSearchValue, onSearchSubmit }) {
  return (
    <section className="bg-warm-gradient w-full py-16 md:py-24 px-4 md:px-10 flex flex-col items-center justify-center text-center">
      <div className="max-w-3xl mx-auto space-y-4">
        {/* Main Title */}
        <h1 className="font-headline-xl text-3xl md:text-5xl font-bold text-on-surface animate-fade-in-up delay-100 tracking-tight">
          Discover Your Next Favorite Recipe
        </h1>

        {/* Subtitle */}
        <p className="font-body-lg text-lg text-secondary max-w-xl mx-auto animate-fade-in-up delay-200">
          Browse hundreds of delicious recipes from breakfast to desserts.
        </p>

        {/* Search Bar Input */}
        <SearchBar
          value={searchValue}
          onChange={setSearchValue}
          onSubmit={onSearchSubmit}
        />
      </div>
    </section>
  );
}
