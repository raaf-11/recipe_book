import React from 'react';
import { CATEGORIES } from '../utils/recipes';

// Horizontal category filter buttons
export default function CategoryFilter({ selectedCategory, onSelectCategory }) {
  return (
    <div className="flex overflow-x-auto pb-3 mb-10 gap-3 snap-x hide-scrollbar">
      {CATEGORIES.map((category) => {
        const isActive = selectedCategory === category;
        return (
          <button
            key={category}
            onClick={() => onSelectCategory(category)}
            className={`whitespace-nowrap px-6 py-2.5 rounded-full font-label-md text-sm font-semibold btn-hover snap-start shrink-0 transition-all duration-200 cursor-pointer ${
              isActive
                ? 'bg-primary-container text-on-primary-container shadow-sm ring-2 ring-primary/20'
                : 'bg-white text-secondary border border-outline-variant hover:border-primary hover:text-primary hover:bg-surface-container-highest'
            }`}
          >
            {category}
          </button>
        );
      })}
    </div>
  );
}
