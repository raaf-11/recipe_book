import React from 'react';
import { Search } from 'lucide-react';

// Search bar input component
export default function SearchBar({ value, onChange, onSubmit }) {
  const handleSubmit = (e) => {
    e.preventDefault();
    if (onSubmit) onSubmit(value);
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="relative max-w-2xl mx-auto mt-8 w-full animate-fade-in-up delay-300 focus-within:scale-[1.01] transition-transform duration-200 ease-in-out"
    >
      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-secondary">
        <Search className="w-5 h-5" />
      </div>

      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Search recipes, ingredients, or categories..."
        className="w-full h-14 md:h-16 pl-12 pr-28 rounded-full bg-white border border-outline-variant shadow-[0_4px_20px_rgba(0,0,0,0.04)] focus:ring-2 focus:ring-primary focus:border-primary font-body-md text-on-surface placeholder:text-slate-400 outline-none transition-all duration-200"
      />

      <button
        type="submit"
        className="absolute inset-y-2 right-2 bg-primary text-on-primary px-6 rounded-full font-label-md text-sm font-semibold btn-hover hover:bg-primary-container hover:text-on-primary-container flex items-center justify-center transition-colors shadow-sm"
      >
        Search
      </button>
    </form>
  );
}
