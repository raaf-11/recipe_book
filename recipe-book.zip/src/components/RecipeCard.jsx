import React from 'react';
import { Bookmark, Clock } from 'lucide-react';

// Reusable Recipe Card component matching exported Stitch design
export default function RecipeCard({ recipe, onToggleBookmark, onClickCard }) {
  const { id, title, cuisine, time, description, image, isBookmarked } = recipe;

  return (
    <article className="group bg-white rounded-2xl shadow-[0_4px_20px_rgba(0,0,0,0.04)] overflow-hidden card-hover flex flex-col border border-slate-100">
      {/* Recipe Thumbnail & Bookmark Button */}
      <div className="relative h-64 w-full overflow-hidden bg-slate-100">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 ring-1 ring-inset ring-black/10 rounded-t-2xl pointer-events-none" />

        {/* Bookmark Action Button */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleBookmark(id);
          }}
          aria-label={`Bookmark ${title}`}
          className={`absolute top-3 right-3 p-2.5 rounded-full backdrop-blur-md transition-all duration-200 active:scale-90 ${
            isBookmarked
              ? 'bg-primary text-white shadow-md'
              : 'bg-white/80 text-secondary hover:text-primary hover:bg-white hover:scale-105 shadow-sm'
          }`}
          title={isBookmarked ? 'Remove Bookmark' : 'Save Bookmark'}
        >
          <Bookmark className={`w-5 h-5 ${isBookmarked ? 'fill-current' : ''}`} />
        </button>
      </div>

      {/* Card Body */}
      <div
        onClick={() => onClickCard && onClickCard(recipe)}
        className="p-6 flex flex-col flex-grow cursor-pointer"
      >
        {/* Category & Cook Time */}
        <div className="flex items-center gap-2 mb-3">
          <span className="inline-flex items-center justify-center px-2.5 py-1 rounded-sm bg-tertiary-fixed text-on-tertiary-fixed font-label-sm text-xs font-semibold uppercase tracking-wider">
            {cuisine}
          </span>
          <div className="flex items-center text-secondary text-xs font-semibold ml-auto">
            <Clock className="w-4 h-4 mr-1 text-secondary" />
            {time}
          </div>
        </div>

        {/* Recipe Title */}
        <h3 className="font-section-header text-xl font-semibold text-on-surface mb-2 line-clamp-1 group-hover:text-primary transition-colors duration-200">
          {title}
        </h3>

        {/* Short Description */}
        <p className="font-body-md text-sm text-secondary line-clamp-2 mt-auto leading-relaxed">
          {description}
        </p>
      </div>
    </article>
  );
}
