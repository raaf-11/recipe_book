import React from 'react';
import { UtensilsCrossed } from 'lucide-react';

// Footer component matching Google Stitch spec
export default function Footer() {
  return (
    <footer className="bg-white w-full py-12 border-t border-outline-variant transition-colors duration-200 mt-auto">
      <div className="flex flex-col md:flex-row justify-between items-center px-6 md:px-10 max-w-[1200px] mx-auto gap-6">
        {/* Brand */}
        <div className="font-headline-md text-2xl font-bold text-on-surface flex items-center gap-2 hover:opacity-80 transition-opacity duration-200 cursor-pointer">
          <UtensilsCrossed className="w-7 h-7 text-primary" />
          <span>Recipe Book</span>
        </div>

        {/* Footer Links */}
        <nav aria-label="Footer Navigation" className="flex flex-wrap justify-center gap-6">
          <a
            href="#about"
            className="font-body-md text-sm text-secondary hover:text-primary transition-colors duration-200 opacity-80 hover:opacity-100"
          >
            About
          </a>
          <a
            href="#privacy"
            className="font-body-md text-sm text-secondary hover:text-primary transition-colors duration-200 opacity-80 hover:opacity-100"
          >
            Privacy Policy
          </a>
          <a
            href="#terms"
            className="font-body-md text-sm text-secondary hover:text-primary transition-colors duration-200 opacity-80 hover:opacity-100"
          >
            Terms of Service
          </a>
          <a
            href="#contact"
            className="font-body-md text-sm text-secondary hover:text-primary transition-colors duration-200 opacity-80 hover:opacity-100"
          >
            Contact
          </a>
        </nav>

        {/* Copyright */}
        <div className="font-body-md text-sm text-secondary">
          © 2024 Recipe Book. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
