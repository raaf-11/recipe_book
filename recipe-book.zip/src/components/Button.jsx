import React from 'react';

// Reusable Button Component with customizable variant and size
export default function Button({
  children,
  onClick,
  type = 'button',
  variant = 'primary',
  className = '',
  disabled = false,
  ...props
}) {
  const baseStyles = 'inline-flex items-center justify-center font-label-md text-label-md font-medium transition-all duration-200 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed';
  
  const variants = {
    primary: 'bg-primary text-on-primary rounded-full px-lg py-2.5 hover:bg-primary-container hover:text-on-primary-container btn-hover shadow-sm',
    secondary: 'bg-surface-container-lowest text-secondary border border-outline-variant rounded-full px-md py-2 hover:border-primary hover:text-primary btn-hover',
    icon: 'p-2 rounded-full text-secondary hover:text-primary hover:bg-surface-container-highest transition-colors active:scale-95',
  };

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`${baseStyles} ${variants[variant] || variants.primary} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
